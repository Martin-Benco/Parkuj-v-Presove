package sk.spsepo.kuchar.easypark;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.maps.android.data.Feature;
import com.google.maps.android.data.geojson.*;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        String spz = prefs.getString("spz", "");
        String phone = prefs.getString("phone", "");
        if (spz.isEmpty() || phone.isEmpty()) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng presov = new LatLng(49.0038, 21.2396);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(presov, 14));

        try {
            boolean success = mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(
                    this, R.raw.map_style));
            if (!success) {
                Toast.makeText(this, "Map style parsing failed.", Toast.LENGTH_SHORT).show();
            }
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }

        try {
            GeoJsonLayer layer = new GeoJsonLayer(mMap, R.raw.parking, getApplicationContext());
            layer.setOnFeatureClickListener(this::showParkingBottomSheet);

            for (GeoJsonFeature feature : layer.getFeatures()) {
                if (feature.hasGeometry() && feature.getGeometry().getGeometryType().equals("Polygon")) {
                    GeoJsonPolygonStyle polygonStyle = new GeoJsonPolygonStyle();
                    polygonStyle.setStrokeWidth(4);
                    String zone = feature.getProperty("Zone");

                    if (zone != null) {
                        if (zone.equalsIgnoreCase("A")) {
                            polygonStyle.setStrokeColor(Color.RED);
                            polygonStyle.setFillColor(Color.argb(100, 255, 0, 0));
                        } else if (zone.startsWith("R")) {
                            polygonStyle.setStrokeColor(Color.rgb(102, 51, 0));
                            polygonStyle.setFillColor(Color.argb(100, 102, 51, 0));
                        } else {
                            polygonStyle.setStrokeColor(Color.GREEN);
                            polygonStyle.setFillColor(Color.argb(100, 0, 255, 0));
                        }
                    } else {
                        polygonStyle.setStrokeColor(Color.GRAY);
                        polygonStyle.setFillColor(Color.argb(100, 128, 128, 128));
                    }

                    feature.setPolygonStyle(polygonStyle);
                }
            }

            layer.addLayerToMap();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Chyba pri načítaní parkovacích zón", Toast.LENGTH_LONG).show();
        }
    }

    private void showParkingBottomSheet(Feature feature) {
        View sheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_parking, null);
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        dialog.setContentView(sheetView);

        TextView nameText = sheetView.findViewById(R.id.parking_name);
        TextView zoneText = sheetView.findViewById(R.id.parking_zone);
        TextView priceText = sheetView.findViewById(R.id.parking_price);
        Spinner spinnerHours = sheetView.findViewById(R.id.spinner_hours);
        Button btnSMS = sheetView.findViewById(R.id.btn_message);

        String name = feature.getProperty("Name");
        String zone = feature.getProperty("Zone");

        nameText.setText(name != null ? name : "Neznáme miesto");
        zoneText.setText(zone != null ? "Zóna: " + zone : "Zóna: neznáma");

        try {
            InputStream is = getResources().openRawResource(R.raw.parking_prices);
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");

            JSONObject prices = new JSONObject(json);
            if (zone != null && prices.has(zone)) {
                JSONObject z = prices.getJSONObject(zone);
                String sadzba = z.getString("sadzba");
                String max = z.getString("max");

                priceText.setText("Sadzba: " + sadzba + "\nDenná max: " + max);

                double rate = parsePrice(sadzba);
                double maxPrice = parsePrice(max);

                if (rate > 0 && maxPrice > 0) {
                    int maxHours = (int) Math.floor(maxPrice / rate);
                    if (maxHours == 0) maxHours = 1;

                    List<Integer> hourOptions = new ArrayList<>();
                    for (int i = 1; i <= maxHours; i++) {
                        hourOptions.add(i);
                    }

                    ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this,
                            android.R.layout.simple_spinner_item,
                            hourOptions);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerHours.setAdapter(adapter);

                    btnSMS.setOnClickListener(v -> {
                        int hours = (int) spinnerHours.getSelectedItem();
                        String sms = generateSMS(zone, hours);
                        Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
                        smsIntent.setData(Uri.parse("smsto:2100"));
                        smsIntent.putExtra("sms_body", sms);
                        startActivity(smsIntent);
                    });
                } else {
                    spinnerHours.setVisibility(View.GONE);
                    btnSMS.setEnabled(false);
                    priceText.append("\n\nNie je možné vypočítať počet hodín.");
                }
            } else {
                priceText.setText("Cenník nie je dostupný.");
            }

        } catch (Exception e) {
            priceText.setText("Chyba pri načítaní cenníka.");
            e.printStackTrace();
        }

        dialog.show();
    }

    private String generateSMS(String zone, int hours) {
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        String spz = prefs.getString("spz", "NEZADANA");
        return zone + " " + spz + " " + hours;
    }

    private double parsePrice(String priceText) {
        try {
            priceText = priceText.replace(",", ".").replaceAll("[^\\d.]", "");
            return Double.parseDouble(priceText);
        } catch (Exception e) {
            return 0.0;
        }
    }
}
