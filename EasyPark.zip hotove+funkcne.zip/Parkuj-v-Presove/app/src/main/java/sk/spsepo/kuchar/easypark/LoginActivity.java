package sk.spsepo.kuchar.easypark;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText inputSpz, inputPhone;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inputSpz = findViewById(R.id.input_spz);
        inputPhone = findViewById(R.id.input_phone);
        btnLogin = findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(v -> {
            String spz = inputSpz.getText().toString().trim();
            String phone = inputPhone.getText().toString().trim();

            if (spz.isEmpty() || phone.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Vyplňte všetky údaje", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("spz", spz);
            editor.putString("phone", phone);
            editor.apply();

            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}

